# Copyright (C) 2002 Python Software Foundation
# Author: barry@zope.com (Barry Warsaw)
